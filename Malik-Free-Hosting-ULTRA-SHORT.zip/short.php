<?php
session_start();
ini_set('display_errors', 0);
error_reporting(0);

$db_file = __DIR__ . '/users.db';
try {
    $db = new PDO('sqlite:' . $db_file);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500); die('Database connection error');
}

$slug = trim($_GET['slug'] ?? '');
if ($slug === '' || !preg_match('/^[A-Za-z0-9]{3}$/', $slug)) {
    http_response_code(400); die('Invalid link');
}

$stmt = $db->prepare('SELECT user_id, actual_filename FROM url_mappings WHERE clean_url = ? LIMIT 1');
$stmt->execute([$slug]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row) { http_response_code(404); die('Link not found'); }

$filename = basename($row['actual_filename']);
$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
$media = ['mp4','webm','avi','mov','mp3','wav','ogg'];
$_GET['file'] = $filename;
$_GET['u'] = (int)$row['user_id'];

if (in_array($ext, $media, true)) {
    require __DIR__ . '/player.php';
} else {
    require __DIR__ . '/view.php';
}
