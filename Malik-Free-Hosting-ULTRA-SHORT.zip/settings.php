<?php
session_start();
error_reporting(0);

// InfinityFree compatibility - prevent anti-bot blocks
if(!isset($_SESSION['page_loaded'])) {
    $_SESSION['page_loaded'] = true;
}

// Admin password - CHANGE THIS TO YOUR OWN PASSWORD
define('ADMIN_PASSWORD', 'Maliksubhan7676'); // Change this to your secure password

// Handle admin logout
if(isset($_GET['logout'])) {
    unset($_SESSION['admin_authenticated']);
    header('Location: index.php');
    exit();
}

// Check admin login
if(isset($_POST['admin_login'])) {
    $entered_password = $_POST['admin_password'];
    if($entered_password === ADMIN_PASSWORD) {
        $_SESSION['admin_authenticated'] = true;
    } else {
        $error = 'Incorrect admin password!';
    }
}

// Check if admin is authenticated
if(!isset($_SESSION['admin_authenticated']) || $_SESSION['admin_authenticated'] !== true) {
    // Show password form
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <style>
    :root{--bg:#dde1e7;--text:#595959;--light:#fff;--dark:#babecc;--blue:#007bff}
    *{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif}
    body{background:var(--bg);min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
    .card{width:100%;max-width:450px;background:var(--bg);border-radius:25px;box-shadow:8px 8px 16px var(--dark),-8px -8px 16px var(--light);padding:40px;text-align:center}
    .shield-icon{font-size:5rem;color:var(--blue);margin-bottom:20px;animation:pulse 2s infinite}
    @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.05)}}
    h1{font-weight:700;color:var(--text);margin-bottom:10px;font-size:1.8rem}
    .sub{font-size:.9rem;color:#888;margin-bottom:30px}
    .field{position:relative;margin-bottom:20px}
    .field i{position:absolute;left:20px;top:50%;transform:translateY(-50%);color:var(--text);z-index:1}
    .input{width:100%;height:50px;background:var(--bg);border:none;border-radius:25px;box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light);padding:0 20px 0 50px;color:var(--text);font-size:1rem;outline:none}
    .btn{width:100%;height:50px;border-radius:25px;background:var(--bg);box-shadow:5px 5px 10px var(--dark),-5px -5px 10px var(--light);border:none;color:var(--text);font-weight:600;font-size:1rem;cursor:pointer;margin-top:20px;display:flex;align-items:center;justify-content:center;transition:.3s}
    .btn:hover{color:var(--blue)}
    .btn:active{box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light)}
    .error{padding:12px;border-radius:15px;margin-bottom:20px;font-size:.85rem;font-weight:600;color:#f44;background:rgba(255,68,68,.1);box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light)}
    .back-link{display:inline-block;margin-top:20px;color:var(--blue);text-decoration:none;font-size:.9rem;font-weight:600}
    .back-link:hover{text-decoration:underline}
    </style>
    </head>
    <body>
    <div class="card">
    <div class="shield-icon"><i class="fas fa-shield-alt"></i></div>
    <h1>Admin Access</h1>
    <p class="sub">Enter admin password to continue</p>
    <?php if(isset($error)): ?><div class="error"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error);?></div><?php endif;?>
    <form method="POST">
    <div class="field">
    <i class="fas fa-lock"></i>
    <input type="password" name="admin_password" class="input" placeholder="Admin Password" required autofocus>
    </div>
    <button type="submit" name="admin_login" class="btn">
    <i class="fas fa-sign-in-alt" style="margin-right:10px;"></i>Access Admin Panel
    </button>
    </form>
    <a href="index.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
    </body>
    </html>
    <?php
    exit();
}

// Check if user is logged in as regular user
if(!isset($_SESSION['logged_in'])) {
    header('Location: index.php');
    exit();
}

$db_file = __DIR__ . '/users.db';
try {
    $db = new PDO('sqlite:' . $db_file);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database error');
}

// Get all users with plain passwords
$stmt = $db->query("
    SELECT u.id, u.username, u.created_at, p.plain_password 
    FROM users u 
    LEFT JOIN user_passwords_plain p ON u.id = p.user_id 
    ORDER BY u.created_at DESC
");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Count files for each user
function countUserFiles($user_id) {
    $upload_dir = __DIR__ . '/uploads/' . $user_id . '/';
    if (!file_exists($upload_dir)) return 0;
    $files = array_diff(scandir($upload_dir), array('.', '..'));
    return count($files);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel - User Database</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#dde1e7;--text:#595959;--light:#fff;--dark:#babecc;--blue:#007bff;--green:#25d366;--red:#f44}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}
body{background:var(--bg);min-height:100vh;padding:20px}
.container{max-width:1200px;margin:0 auto}
.header{background:var(--bg);border-radius:25px;box-shadow:8px 8px 16px var(--dark),-8px -8px 16px var(--light);padding:30px;margin-bottom:30px;text-align:center}
.header h1{font-size:2rem;color:var(--text);margin-bottom:10px;display:flex;align-items:center;justify-content:center;gap:15px}
.header h1 i{color:var(--blue);font-size:2.2rem}
.header p{color:#888;font-size:.95rem}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:30px}
.stat-card{background:var(--bg);border-radius:20px;box-shadow:6px 6px 12px var(--dark),-6px -6px 12px var(--light);padding:25px;text-align:center}
.stat-card i{font-size:2.5rem;margin-bottom:10px}
.stat-card .number{font-size:2rem;font-weight:700;color:var(--text);margin-bottom:5px}
.stat-card .label{font-size:.85rem;color:#888;font-weight:600}
.back-btn{display:inline-flex;align-items:center;gap:10px;padding:12px 25px;background:var(--bg);border-radius:20px;box-shadow:5px 5px 10px var(--dark),-5px -5px 10px var(--light);color:var(--text);text-decoration:none;font-weight:600;margin-bottom:20px;transition:.3s}
.back-btn:hover{color:var(--blue)}
.back-btn:active{box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light)}
.users-table{background:var(--bg);border-radius:25px;box-shadow:inset 8px 8px 16px var(--dark),inset -8px -8px 16px var(--light);padding:30px;overflow-x:auto}
.table-header{display:flex;align-items:center;gap:10px;margin-bottom:20px;padding-bottom:15px;border-bottom:2px solid var(--dark)}
.table-header i{color:var(--blue);font-size:1.3rem}
.table-header h2{color:var(--text);font-size:1.3rem;margin:0}
table{width:100%;border-collapse:collapse}
thead{background:var(--bg);border-radius:15px}
thead th{padding:15px 10px;text-align:left;font-size:.85rem;color:#888;font-weight:600;text-transform:uppercase;letter-spacing:.5px}
tbody tr{border-bottom:1px solid rgba(0,0,0,.05)}
tbody td{padding:15px 10px;color:var(--text);font-size:.9rem}
.user-info{display:flex;align-items:center;gap:10px}
.user-avatar{width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,var(--blue),#0056b3);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:1.1rem;box-shadow:3px 3px 6px var(--dark),-3px -3px 6px var(--light)}
.user-details{flex:1}
.username{font-weight:600;color:var(--text);margin-bottom:2px}
.user-id{font-size:.75rem;color:#888}
.password-box{background:var(--bg);padding:8px 15px;border-radius:12px;box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light);font-family:monospace;font-size:.85rem;color:var(--blue);font-weight:600;display:inline-block;cursor:pointer;position:relative}
.password-box:hover{color:#0056b3}
.copy-btn{background:var(--bg);border:none;padding:8px 12px;border-radius:10px;box-shadow:3px 3px 6px var(--dark),-3px -3px 6px var(--light);color:var(--text);cursor:pointer;font-size:.75rem;font-weight:600;transition:.3s}
.copy-btn:hover{color:var(--blue)}
.copy-btn:active{box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light)}
.badge{display:inline-flex;align-items:center;gap:5px;padding:6px 12px;border-radius:12px;font-size:.75rem;font-weight:600;box-shadow:inset 2px 2px 5px var(--dark),inset -2px -2px 5px var(--light)}
.badge.green{color:var(--green)}
.badge.blue{color:var(--blue)}
.date-text{font-size:.8rem;color:#888}
input,button{-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}
@media(max-width:768px){.stats{grid-template-columns:1fr}.users-table{padding:20px;overflow-x:scroll}table{min-width:800px}}
</style>
</head>
<body>
<div class="container">

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
<a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i>Back to Dashboard</a>
<a href="?logout=1" class="back-btn" style="background:linear-gradient(135deg,rgba(255,68,68,.1),rgba(255,68,68,.05));color:#f44" onclick="return confirm('Logout from admin panel?')"><i class="fas fa-sign-out-alt"></i>Logout</a>
</div>

<div class="header">
<h1><i class="fas fa-shield-alt"></i>Admin Panel</h1>
<p>Complete User Database & Management System</p>
</div>

<div class="stats">
<div class="stat-card">
<i class="fas fa-users" style="color:var(--blue)"></i>
<div class="number"><?php echo count($users);?></div>
<div class="label">Total Users</div>
</div>
<div class="stat-card">
<i class="fas fa-user-check" style="color:var(--green)"></i>
<div class="number"><?php echo count(array_filter($users, function($u){ return countUserFiles($u['id']) > 0; }));?></div>
<div class="label">Active Users</div>
</div>
<div class="stat-card">
<i class="fas fa-folder" style="color:#f39c12)"></i>
<div class="number"><?php 
$total_files = 0;
foreach($users as $u) $total_files += countUserFiles($u['id']);
echo $total_files;
?></div>
<div class="label">Total Files</div>
</div>
</div>

<div class="users-table">
<div class="table-header">
<i class="fas fa-database"></i>
<h2>User Database</h2>
</div>

<table>
<thead>
<tr>
<th>User</th>
<th>Username</th>
<th>Password</th>
<th>Files</th>
<th>Joined Date</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($users as $user): ?>
<tr>
<td>
<div class="user-info">
<div class="user-avatar"><?php echo strtoupper(substr($user['username'], 0, 1));?></div>
<div class="user-details">
<div class="username"><?php echo htmlspecialchars($user['username']);?></div>
<div class="user-id">ID: <?php echo $user['id'];?></div>
</div>
</div>
</td>
<td>
<span class="badge blue">
<i class="fas fa-user"></i>
<?php echo htmlspecialchars($user['username']);?>
</span>
</td>
<td>
<div class="password-box" onclick="copyText('<?php echo htmlspecialchars($user['plain_password'] ?? 'N/A');?>')">
<?php echo htmlspecialchars($user['plain_password'] ?? 'Not Available');?>
<i class="fas fa-copy" style="margin-left:8px;font-size:.7rem;"></i>
</div>
</td>
<td>
<span class="badge <?php echo countUserFiles($user['id']) > 0 ? 'green' : 'blue';?>">
<i class="fas fa-file"></i>
<?php echo countUserFiles($user['id']);?> files
</span>
</td>
<td>
<div class="date-text">
<i class="far fa-calendar"></i>
<?php echo date('M d, Y', strtotime($user['created_at']));?>
<br>
<span style="font-size:.7rem;"><?php echo date('h:i A', strtotime($user['created_at']));?></span>
</div>
</td>
<td>
<button class="copy-btn" onclick="copyText('<?php echo addslashes(htmlspecialchars($user['username']));?>')">
<i class="fas fa-copy"></i> Copy
</button>
</td>
</tr>
<?php endforeach;?>
</tbody>
</table>

</div>

</div>

<script>
function copyText(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('Copied: ' + text);
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('Copied: ' + text);
    });
}

// Disable right-click
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});
</script>

</body>
</html>
