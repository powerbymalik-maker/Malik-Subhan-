<?php
session_start();
error_reporting(0);

$db_file = __DIR__ . '/users.db';
try {
    $db = new PDO('sqlite:' . $db_file);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // New table for file passwords
    $db->exec("CREATE TABLE IF NOT EXISTS file_passwords (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        password TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // New table for plain passwords (for admin view only)
    $db->exec("CREATE TABLE IF NOT EXISTS user_passwords_plain (
        user_id INTEGER PRIMARY KEY,
        plain_password TEXT NOT NULL
    )");
    
    // New table for URL mapping (clean URLs)
    $db->exec("CREATE TABLE IF NOT EXISTS url_mappings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        clean_url TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        actual_filename TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
} catch (PDOException $e) {
    die('Database error');
}

// Check if any users exist
$stmt = $db->query("SELECT COUNT(*) as count FROM users");
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$has_users = $result['count'] > 0;

if (isset($_POST['signup'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    if (!empty($username) && !empty($password)) {
        try {
            $stmt = $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
            
            // Get the inserted user ID
            $user_id = $db->lastInsertId();
            
            // Store plain password for admin view
            $stmt = $db->prepare("INSERT INTO user_passwords_plain (user_id, plain_password) VALUES (?, ?)");
            $stmt->execute([$user_id, $password]);
            
            // Auto login after signup
            $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $_SESSION['logged_in'] = true;
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header('Location: index.php');
            exit();
        } catch (PDOException $e) {
            $error = "Username already exists!";
        }
    } else {
        $error = "Please fill all fields!";
    }
}

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['logged_in'] = true;
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header('Location: index.php');
            exit();
        } else {
            $error = "Invalid credentials!";
        }
    } catch (PDOException $e) {
        $error = "Login error!";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

if (isset($_POST['upload']) && isset($_SESSION['logged_in'])) {
    $user_id = $_SESSION['user_id'];
    $upload_dir = __DIR__ . '/uploads/' . $user_id . '/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0755, true);
        @chmod($upload_dir, 0755);
    }
    
    if (isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
        $custom_name = trim($_POST['custom_name'] ?? '');
        $file_name = basename($_FILES['file']['name']);
        
        if (!empty($custom_name)) {
            $ext = pathinfo($file_name, PATHINFO_EXTENSION);
            $file_name = $custom_name . '.' . $ext;
        }
        
        $target_file = $upload_dir . $file_name;
        
        // If file exists, add number to make it unique
        $counter = 1;
        $original_name = $file_name;
        while (file_exists($target_file)) {
            $name_without_ext = pathinfo($original_name, PATHINFO_FILENAME);
            $ext = pathinfo($original_name, PATHINFO_EXTENSION);
            $file_name = $name_without_ext . '_' . $counter . '.' . $ext;
            $target_file = $upload_dir . $file_name;
            $counter++;
        }
        
        if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
            // Set file permissions to readable
            @chmod($target_file, 0644);
            getOrCreateCleanSlug($db, $user_id, basename($target_file));
            
            // Save password if provided
            $file_password = trim($_POST['file_password'] ?? '');
            if (!empty($file_password)) {
                $stmt = $db->prepare("INSERT INTO file_passwords (user_id, filename, password) VALUES (?, ?, ?)");
                $stmt->execute([$user_id, basename($target_file), password_hash($file_password, PASSWORD_DEFAULT)]);
            }
            header('Location: index.php?cat=' . ($_GET['cat'] ?? '') . '&success=1');
            exit();
        }
    }
}

if (isset($_POST['upload_text']) && isset($_SESSION['logged_in'])) {
    $user_id = $_SESSION['user_id'];
    $upload_dir = __DIR__ . '/uploads/' . $user_id . '/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0755, true);
        @chmod($upload_dir, 0755);
    }
    
    $custom_name = trim($_POST['custom_name'] ?? '');
    $text_content = $_POST['text_content'] ?? '';
    $category = $_GET['cat'] ?? '';
    
    if (!empty($custom_name) && !empty($text_content)) {
        $ext_map = ['html' => 'html', 'css' => 'css', 'js' => 'js', 'php' => 'php'];
        $ext = $ext_map[$category] ?? 'txt';
        
        if (!preg_match('/\.' . $ext . '$/', $custom_name)) {
            $file_name = $custom_name . '.' . $ext;
        } else {
            $file_name = $custom_name;
        }
        
        $target_file = $upload_dir . $file_name;
        
        // If file exists, add number to make it unique
        $counter = 1;
        $original_name = $file_name;
        while (file_exists($target_file)) {
            $name_without_ext = pathinfo($original_name, PATHINFO_FILENAME);
            $ext = pathinfo($original_name, PATHINFO_EXTENSION);
            $file_name = $name_without_ext . '_' . $counter . '.' . $ext;
            $target_file = $upload_dir . $file_name;
            $counter++;
        }
        
        if (file_put_contents($target_file, $text_content)) {
            // Set file permissions to readable
            @chmod($target_file, 0644);
            getOrCreateCleanSlug($db, $user_id, basename($target_file));
            
            // Save password if provided
            $file_password = trim($_POST['file_password'] ?? '');
            if (!empty($file_password)) {
                $stmt = $db->prepare("INSERT INTO file_passwords (user_id, filename, password) VALUES (?, ?, ?)");
                $stmt->execute([$user_id, basename($target_file), password_hash($file_password, PASSWORD_DEFAULT)]);
            }
            header('Location: index.php?cat=' . $category . '&success=1');
            exit();
        }
    } else {
        header('Location: index.php?cat=' . $category . '&error=1');
        exit();
    }
}

if (isset($_GET['delete']) && isset($_SESSION['logged_in'])) {
    $user_id = $_SESSION['user_id'];
    $file = __DIR__ . '/uploads/' . $user_id . '/' . basename($_GET['delete']);
    if (file_exists($file)) {
        unlink($file);
        // Delete password entry if exists
        $stmt = $db->prepare("DELETE FROM file_passwords WHERE user_id = ? AND filename = ?");
        $stmt->execute([$user_id, basename($_GET['delete'])]);
        $stmt = $db->prepare("DELETE FROM url_mappings WHERE user_id = ? AND actual_filename = ?");
        $stmt->execute([$user_id, basename($_GET['delete'])]);
        header('Location: index.php?cat=' . ($_GET['cat'] ?? ''));
        exit();
    }
}

$category = $_GET['cat'] ?? '';
$upload_mode = $_GET['mode'] ?? 'file'; // 'file' or 'text'

function getFiles($user_id, $category = '') {
    $upload_dir = __DIR__ . '/uploads/' . $user_id . '/';
    if (!file_exists($upload_dir)) return [];
    $files = array_diff(scandir($upload_dir, SCANDIR_SORT_DESCENDING), array('.', '..'));
    if ($category) {
        $ext = ['html'=>['html','htm'],'css'=>['css'],'js'=>['js'],'php'=>['php'],'img'=>['jpg','jpeg','png','gif','webp','svg'],'video'=>['mp4','avi','mov','webm'],'music'=>['mp3','wav','ogg']];
        if (isset($ext[$category])) {
            $files = array_filter($files, function($f) use ($ext, $category, $upload_dir) {
                return in_array(strtolower(pathinfo($upload_dir.$f, PATHINFO_EXTENSION)), $ext[$category]);
            });
        }
    }
    return array_values($files);
}

function isPasswordProtected($db, $user_id, $filename) {
    $stmt = $db->prepare("SELECT id FROM file_passwords WHERE user_id = ? AND filename = ?");
    $stmt->execute([$user_id, $filename]);
    return $stmt->fetch(PDO::FETCH_ASSOC) !== false;
}

function getOrCreateCleanSlug($db, $user_id, $filename) {
    $stmt = $db->prepare("SELECT clean_url FROM url_mappings WHERE user_id = ? AND actual_filename = ? LIMIT 1");
    $stmt->execute([$user_id, $filename]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) return $row['clean_url'];
    do {
        $slug = substr(strtr(base64_encode(random_bytes(3)), '+/', '-_'), 0, 3);
        $slug = preg_replace('/[^A-Za-z0-9]/', '', $slug);
        if (strlen($slug) < 3) continue;
        $stmt = $db->prepare("SELECT id FROM url_mappings WHERE clean_url = ?");
        $stmt->execute([$slug]);
    } while ($stmt->fetch(PDO::FETCH_ASSOC));
    $stmt = $db->prepare("INSERT INTO url_mappings (clean_url, user_id, actual_filename) VALUES (?, ?, ?)");
    $stmt->execute([$slug, $user_id, $filename]);
    return $slug;
}

$files = isset($_SESSION['logged_in']) ? getFiles($_SESSION['user_id'], $category) : [];

function getFileLink($user_id, $file) {
    global $db;
    $p = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ? 'https' : 'http';
    $base_url = $p . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['PHP_SELF']), '/');
    $slug = getOrCreateCleanSlug($db, $user_id, $file);
    return $base_url . '/' . rawurlencode($slug);
}


$text_categories = ['html', 'css', 'js', 'php'];
$is_text_category = in_array($category, $text_categories);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Malik Free Hosting</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#dde1e7;--text:#595959;--light:#fff;--dark:#babecc;--blue:#007bff;--green:#25d366}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}
body{background:var(--bg);min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
input,textarea{-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}
.card{width:100%;max-width:600px;background:var(--bg);border-radius:25px;box-shadow:8px 8px 16px var(--dark),-8px -8px 16px var(--light);padding:40px;text-align:center}
.btn{width:100%;height:50px;border-radius:25px;background:var(--bg);box-shadow:5px 5px 10px var(--dark),-5px -5px 10px var(--light);border:none;color:var(--text);font-weight:600;font-size:1rem;cursor:pointer;margin-top:20px;display:flex;align-items:center;justify-content:center;text-decoration:none;transition:.3s}
.btn:hover{color:var(--blue)}
.btn:active{box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light)}
.input{width:100%;height:50px;background:var(--bg);border:none;border-radius:25px;box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light);padding:0 20px 0 50px;color:var(--text);font-size:1rem;outline:none}
.field{position:relative;margin-bottom:20px}
.field i{position:absolute;left:20px;top:50%;transform:translateY(-50%);color:var(--text);z-index:1}
h1,h3{font-weight:700;color:var(--text);margin-bottom:10px;font-size:1.8rem}
.sub{font-size:.9rem;color:#888;margin-bottom:30px}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:20px;margin-top:30px}
.item{background:var(--bg);border-radius:20px;padding:30px 20px;box-shadow:6px 6px 12px var(--dark),-6px -6px 12px var(--light);cursor:pointer;display:flex;flex-direction:column;align-items:center;min-height:120px;transition:.3s}
.item:hover{transform:translateY(-2px)}
.item:active{box-shadow:inset 6px 6px 12px var(--dark),inset -6px -6px 12px var(--light);transform:translateY(0)}
.item i{font-size:2.5rem;color:var(--blue);margin-bottom:10px}
.item b{font-size:.9rem;color:var(--text)}
.alert{padding:12px;border-radius:15px;margin-bottom:20px;font-size:.85rem;font-weight:600}
.err{color:#f44;background:rgba(255,68,68,.1);box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light)}
.ok{color:#00b894;background:rgba(0,184,148,.1);box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light)}
.back{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:5px 5px 10px var(--dark),-5px -5px 10px var(--light);color:var(--text);text-decoration:none;margin-right:15px;cursor:pointer}
.back:active{box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light)}
.top{display:flex;align-items:center;margin-bottom:20px}
.link{color:var(--blue);cursor:pointer;font-weight:600}
.link:hover{text-decoration:underline}
.upload-box{background:var(--bg);border-radius:25px;box-shadow:inset 8px 8px 16px var(--dark),inset -8px -8px 16px var(--light);padding:60px 30px;margin-bottom:20px;text-align:center}
.cloud{font-size:5rem;color:var(--blue);margin-bottom:20px}
.file-label{display:inline-block;padding:12px 30px;background:var(--bg);border-radius:20px;box-shadow:5px 5px 10px var(--dark),-5px -5px 10px var(--light);cursor:pointer;font-weight:600;color:var(--text);border:2px solid var(--text);margin-bottom:10px}
.file-label:active{box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light)}
.chosen{display:block;margin-top:10px;font-size:.9rem;color:#888}
.upload{width:100%;height:55px;border-radius:25px;background:var(--bg);box-shadow:5px 5px 10px var(--dark),-5px -5px 10px var(--light);border:none;color:var(--text);font-weight:700;font-size:1.1rem;cursor:pointer;text-transform:uppercase;letter-spacing:1px}
.upload:hover{color:var(--blue)}
.upload:active{box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light)}
.list{margin-top:30px}
.list-title{color:var(--blue);font-size:1.2rem;font-weight:700;text-align:left;margin-bottom:20px}
.file{background:var(--bg);border-radius:20px;padding:20px;box-shadow:4px 4px 8px var(--dark),-4px -4px 8px var(--light);margin-bottom:15px}
.file-top{display:flex;align-items:center;margin-bottom:15px}
.file-top i{font-size:1.5rem;color:var(--blue);margin-right:15px}
.file-name{flex:1;font-size:.9rem;color:var(--text);font-weight:600;word-break:break-word}
.actions{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.act{padding:10px;border-radius:15px;box-shadow:3px 3px 6px var(--dark),-3px -3px 6px var(--light);border:none;font-weight:600;font-size:.8rem;cursor:pointer;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:5px;color:var(--text)}
.act:active{box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light)}
.act.view{color:var(--blue)}
.act.copy{color:#00b894}
.act.del{color:#f44}
.empty{text-align:center;padding:30px;color:#999}
.wa{color:var(--green)}
.wa:hover{color:#128c7e}
.name-input{width:100%;height:50px;background:var(--bg);border:none;border-radius:25px;box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light);padding:0 20px;color:var(--text);font-size:1rem;outline:none;margin-bottom:20px}
.text-area{width:100%;min-height:200px;background:var(--bg);border:none;border-radius:20px;box-shadow:inset 6px 6px 12px var(--dark),inset -6px -6px 12px var(--light);padding:20px;color:var(--text);font-size:.9rem;outline:none;resize:vertical;font-family:monospace;margin-bottom:20px}
.mode-switch{display:flex;gap:10px;margin-bottom:20px}
.mode-btn{flex:1;height:45px;border-radius:20px;background:var(--bg);box-shadow:5px 5px 10px var(--dark),-5px -5px 10px var(--light);border:none;color:var(--text);font-weight:600;font-size:.9rem;cursor:pointer;transition:.3s}
.mode-btn.active{box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light);color:var(--blue)}
.mode-btn:hover{color:var(--blue)}
.progress-container{display:none;margin-top:20px;margin-bottom:20px}
.progress-bar{width:100%;height:30px;background:var(--bg);border-radius:15px;box-shadow:inset 4px 4px 8px var(--dark),inset -4px -4px 8px var(--light);overflow:hidden;position:relative}
.progress-fill{height:100%;background:linear-gradient(90deg,var(--blue),#0056b3);border-radius:15px;width:0%;transition:width .3s;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.85rem}
.password-section{background:var(--bg);border-radius:20px;box-shadow:inset 4px 4px 8px var(--dark),inset -4px -4px 8px var(--light);padding:20px;margin-bottom:20px}
.password-title{display:flex;align-items:center;gap:10px;color:var(--text);font-weight:600;font-size:.9rem;margin-bottom:15px}
.password-title i{color:var(--blue)}
.password-info{font-size:.75rem;color:#888;margin-bottom:15px}
.password-input{width:100%;height:45px;background:var(--bg);border:none;border-radius:20px;box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light);padding:0 15px;color:var(--text);font-size:.9rem;outline:none}
.preview-container{margin-top:20px;margin-bottom:20px;background:var(--bg);border-radius:20px;box-shadow:inset 6px 6px 12px var(--dark),inset -6px -6px 12px var(--light);padding:20px;display:none}
.preview-title{color:var(--blue);font-weight:700;font-size:1rem;margin-bottom:15px;display:flex;align-items:center;gap:10px}
.preview-content{border-radius:15px;overflow:hidden;box-shadow:4px 4px 8px var(--dark),-4px -4px 8px var(--light)}
.preview-content img{max-width:100%;display:block;border-radius:15px}
.preview-content video,.preview-content audio{width:100%;border-radius:15px}
.protected-badge{display:inline-flex;align-items:center;gap:5px;padding:4px 10px;background:rgba(255,193,7,.2);border-radius:10px;font-size:.7rem;color:#ffc107;font-weight:600;margin-left:10px}
@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
@media(max-width:768px){.card{padding:30px 20px}.grid{gap:15px}.item{padding:20px 15px;min-height:100px}.item i{font-size:2rem}.actions{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="card">
<?php if(!isset($_SESSION['logged_in'])): ?>
<?php if(!$has_users): ?>
<h1>Sign Up</h1>
<p class="sub">Create your hosting account</p>
<?php if(isset($error)): ?><div class="alert err"><?php echo htmlspecialchars($error);?></div><?php endif;?>
<form method="POST">
<div class="field"><i class="fas fa-user"></i><input type="text" name="username" class="input" placeholder="Username" required></div>
<div class="field"><i class="fas fa-lock"></i><input type="password" name="password" class="input" placeholder="Password" required></div>
<button type="submit" name="signup" class="btn"><i class="fas fa-user-plus" style="margin-right:10px;"></i>Sign Up</button>
</form>
<?php else: ?>
<?php if(!isset($_GET['signup'])): ?>
<h1>Login</h1>
<p class="sub">Access your hosting panel</p>
<?php if(isset($error)): ?><div class="alert err"><?php echo htmlspecialchars($error);?></div><?php endif;?>
<form method="POST">
<div class="field"><i class="fas fa-user"></i><input type="text" name="username" class="input" placeholder="Username" required></div>
<div class="field"><i class="fas fa-lock"></i><input type="password" name="password" class="input" placeholder="Password" required></div>
<button type="submit" name="login" class="btn"><i class="fas fa-sign-in-alt" style="margin-right:10px;"></i>Login</button>
</form>
<div style="margin-top:25px;font-size:.9rem;color:#888">Don't have an account? <span class="link" onclick="location.href='?signup=1'">Sign Up</span></div>
<?php else: ?>
<h1>Sign Up</h1>
<p class="sub">Create your hosting account</p>
<?php if(isset($error)): ?><div class="alert err"><?php echo htmlspecialchars($error);?></div><?php endif;?>
<form method="POST">
<div class="field"><i class="fas fa-user"></i><input type="text" name="username" class="input" placeholder="Username" required></div>
<div class="field"><i class="fas fa-lock"></i><input type="password" name="password" class="input" placeholder="Password" required></div>
<button type="submit" name="signup" class="btn"><i class="fas fa-user-plus" style="margin-right:10px;"></i>Sign Up</button>
</form>
<div style="margin-top:25px;font-size:.9rem;color:#888">Already have an account? <span class="link" onclick="location.href='index.php'">Login</span></div>
<?php endif;?>
<?php endif;?>
<?php elseif($category): ?>
<div class="top">
<a href="index.php" class="back"><i class="fas fa-arrow-left"></i></a>
<h3 style="margin:0;"><?php echo strtoupper($category);?> MANAGER</h3>
</div>
<?php if(isset($_GET['success'])): ?><div class="alert ok">File uploaded successfully!</div><?php endif;?>
<?php if(isset($_GET['error'])): ?><div class="alert err">Upload failed!</div><?php endif;?>

<?php if($is_text_category): ?>
<div class="mode-switch">
<button class="mode-btn <?php echo $upload_mode=='file'?'active':'';?>" onclick="location.href='?cat=<?php echo $category;?>&mode=file'"><i class="fas fa-folder-open"></i> Choose File</button>
<button class="mode-btn <?php echo $upload_mode=='text'?'active':'';?>" onclick="location.href='?cat=<?php echo $category;?>&mode=text'"><i class="fas fa-keyboard"></i> Paste & Upload</button>
</div>
<?php endif;?>

<?php if($upload_mode=='text' && $is_text_category): ?>
<form method="POST" id="textForm" onsubmit="return handleTextUpload(event)">
<input type="text" name="custom_name" class="name-input" placeholder="Enter file name (e.g., myfile)" required>
<textarea name="text_content" class="text-area" placeholder="Paste your <?php echo strtoupper($category);?> code here..." required></textarea>

<div class="password-section">
<div class="password-title"><i class="fas fa-shield-alt"></i>Password Protection (Optional)</div>
<div class="password-info">Leave empty for public access, or set a password for private files</div>
<input type="password" name="file_password" class="password-input" placeholder="Enter password (optional)">
</div>

<div class="progress-container" id="textProgress">
<div class="progress-bar"><div class="progress-fill" id="textProgressFill">0%</div></div>
</div>

<input type="hidden" name="upload_text" value="1">
<button type="submit" class="upload" id="textUploadBtn">Paste & Upload</button>
</form>
<?php else: ?>
<form method="POST" enctype="multipart/form-data" id="fileForm" onsubmit="return handleUpload(event)">
<input type="text" name="custom_name" class="name-input" placeholder="Custom file name (optional)">
<div class="upload-box">
<div class="cloud"><i class="fas fa-cloud-upload-alt"></i></div>
<label for="file" class="file-label">Choose File</label>
<input id="file" type="file" name="file" style="display:none;" onchange="updateFile(this)">
<span class="chosen" id="chosen">No file chosen</span>
</div>

<div class="preview-container" id="previewContainer">
<div class="preview-title"><i class="fas fa-eye"></i>Preview</div>
<div class="preview-content" id="previewContent"></div>
</div>

<div class="password-section">
<div class="password-title"><i class="fas fa-shield-alt"></i>Password Protection (Optional)</div>
<div class="password-info">Leave empty for public access, or set a password for private files</div>
<input type="password" name="file_password" class="password-input" placeholder="Enter password (optional)">
</div>

<div class="progress-container" id="progressContainer">
<div class="progress-bar"><div class="progress-fill" id="progressFill">0%</div></div>
</div>

<input type="hidden" name="upload" value="1">
<button type="submit" class="upload" id="uploadBtn">Upload File</button>
</form>
<?php endif;?>

<?php if(count($files)>0): ?>
<div class="list">
<div class="list-title">Your Files</div>
<?php foreach($files as $f): 
$link=getFileLink($_SESSION['user_id'],$f);
$is_protected = isPasswordProtected($db, $_SESSION['user_id'], $f);
?>
<div class="file">
<div class="file-top">
<i class="fas fa-file-alt"></i>
<div class="file-name">
<?php echo htmlspecialchars($f);?>
<?php if($is_protected): ?><span class="protected-badge"><i class="fas fa-lock"></i>Protected</span><?php endif;?>
</div>
</div>
<div class="actions">
<a href="<?php echo $link;?>" class="act view" target="_blank"><i class="fas fa-eye"></i>View</a>
<button class="act copy" onclick="copy('<?php echo addslashes($link);?>')"><i class="fas fa-copy"></i>Copy Link</button>
<a href="?cat=<?php echo $category;?>&delete=<?php echo urlencode($f);?>" class="act del" onclick="return confirm('Delete this file?')"><i class="fas fa-trash"></i>Delete</a>
</div>
</div>
<?php endforeach;?>
</div>
<?php else: ?>
<div class="empty">No files found.</div>
<?php endif;?>
<?php else: ?>
<div style="position:relative;">
<a href="settings.php" style="position:absolute;top:0;right:0;width:35px;height:35px;display:flex;align-items:center;justify-content:center;text-decoration:none;animation:spin 3s linear infinite">
<i class="fas fa-cog" style="font-size:1.3rem;color:var(--text);"></i>
</a>
<h3 style="margin:0;padding-right:40px;">Welcome, <?php echo htmlspecialchars($_SESSION['username']);?></h3>
</div>
<p class="sub">Manage your content</p>

<div class="grid">
<div class="item" onclick="location.href='?cat=html'"><i class="fab fa-html5"></i><b>HTML</b></div>
<div class="item" onclick="location.href='?cat=css'"><i class="fab fa-css3-alt"></i><b>CSS</b></div>
<div class="item" onclick="location.href='?cat=js'"><i class="fas fa-file-code"></i><b>JAVASCRIPT</b></div>
<div class="item" onclick="location.href='?cat=php'"><i class="fab fa-php"></i><b>PHP</b></div>
<div class="item" onclick="location.href='?cat=img'"><i class="fas fa-image"></i><b>IMAGES</b></div>
<div class="item" onclick="location.href='?cat=video'"><i class="fas fa-video"></i><b>VIDEO</b></div>
<div class="item" onclick="location.href='?cat=music'"><i class="fas fa-music"></i><b>MUSIC</b></div>
<div class="item" onclick="if(confirm('Logout?'))location.href='?logout=1'"><i class="fas fa-power-off" style="color:#f44;"></i><b style="color:#f44;">LOGOUT</b></div>
</div>
<a href="https://whatsapp.com/channel/0029Vb73nXdGpLHOf9F6Gh3Y" target="_blank" class="btn wa"><i class="fab fa-whatsapp" style="margin-right:10px;font-size:1.2rem;"></i>Join WhatsApp</a>
<?php endif;?>
</div>
<script>
// Disable right-click context menu
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
    return false;
});

// Disable text selection on double click
document.addEventListener('selectstart', function(e) {
    if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
        e.preventDefault();
        return false;
    }
});

// Disable copy
document.addEventListener('copy', function(e) {
    if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
        e.preventDefault();
        return false;
    }
});

function updateFile(input) {
    const file = input.files[0];
    document.getElementById('chosen').textContent = file ? file.name : 'No file chosen';
    
    if (file) {
        const previewContainer = document.getElementById('previewContainer');
        const previewContent = document.getElementById('previewContent');
        
        // Show instant preview for media
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewContent.innerHTML = '<img src="' + e.target.result + '" alt="Preview">';
                previewContainer.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else if (file.type.startsWith('video/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewContent.innerHTML = '<video controls><source src="' + e.target.result + '" type="' + file.type + '">Your browser does not support video.</video>';
                previewContainer.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else if (file.type.startsWith('audio/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewContent.innerHTML = '<audio controls style="width:100%;"><source src="' + e.target.result + '" type="' + file.type + '">Your browser does not support audio.</audio>';
                previewContainer.style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            previewContainer.style.display = 'none';
        }
    }
}

function handleUpload(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const progressContainer = document.getElementById('progressContainer');
    const progressFill = document.getElementById('progressFill');
    const uploadBtn = document.getElementById('uploadBtn');
    
    progressContainer.style.display = 'block';
    uploadBtn.disabled = true;
    uploadBtn.textContent = 'UPLOADING...';
    
    const xhr = new XMLHttpRequest();
    
    xhr.upload.addEventListener('progress', function(e) {
        if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 100);
            progressFill.style.width = percent + '%';
            progressFill.textContent = percent + '%';
        }
    });
    
    xhr.addEventListener('load', function() {
        if (xhr.status === 200) {
            progressFill.style.width = '100%';
            progressFill.textContent = '100%';
            setTimeout(() => {
                window.location.href = form.action || window.location.href;
            }, 500);
        } else {
            alert('Upload failed!');
            progressContainer.style.display = 'none';
            uploadBtn.disabled = false;
            uploadBtn.textContent = 'UPLOAD FILE';
        }
    });
    
    xhr.addEventListener('error', function() {
        alert('Upload error!');
        progressContainer.style.display = 'none';
        uploadBtn.disabled = false;
        uploadBtn.textContent = 'UPLOAD FILE';
    });
    
    xhr.open('POST', form.action || window.location.href);
    xhr.send(formData);
    
    return false;
}

function handleTextUpload(event) {
    event.preventDefault();
    
    const form = event.target;
    const progressContainer = document.getElementById('textProgress');
    const progressFill = document.getElementById('textProgressFill');
    const uploadBtn = document.getElementById('textUploadBtn');
    
    progressContainer.style.display = 'block';
    uploadBtn.disabled = true;
    uploadBtn.textContent = 'UPLOADING...';
    
    let progress = 0;
    const interval = setInterval(() => {
        progress += 10;
        progressFill.style.width = progress + '%';
        progressFill.textContent = progress + '%';
        
        if (progress >= 90) {
            clearInterval(interval);
        }
    }, 50);
    
    const formData = new FormData(form);
    
    fetch(form.action || window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        clearInterval(interval);
        progressFill.style.width = '100%';
        progressFill.textContent = '100%';
        
        setTimeout(() => {
            if (response.ok) {
                window.location.href = form.action || window.location.href;
            } else {
                throw new Error('Upload failed');
            }
        }, 300);
    })
    .catch(error => {
        clearInterval(interval);
        alert('Upload failed!');
        progressContainer.style.display = 'none';
        uploadBtn.disabled = false;
        uploadBtn.textContent = 'PASTE & UPLOAD';
    });
    
    return false;
}

function copy(l){navigator.clipboard.writeText(l).then(()=>alert('Link copied!'),()=>{const t=document.createElement('textarea');t.value=l;document.body.appendChild(t);t.select();document.execCommand('copy');document.body.removeChild(t);alert('Link copied!')})}
</script>
</body>
</html>
