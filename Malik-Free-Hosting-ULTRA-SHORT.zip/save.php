<?php
error_reporting(0);
session_start();

if (!isset($_SESSION['logged_in']) || !isset($_POST['filename']) || !isset($_POST['code'])) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$category = $_GET['cat'] ?? '';
$filename = basename($_POST['filename']);
$code = $_POST['code'];

$upload_dir = __DIR__ . '/uploads/' . $user_id . '/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

$file_path = $upload_dir . $filename;

if (file_put_contents($file_path, $code)) {
    header('Location: index.php?cat=' . urlencode($category) . '&success=File saved successfully!');
} else {
    header('Location: index.php?cat=' . urlencode($category) . '&error=Failed to save file!');
}
exit();
?>