<?php
session_start();
ini_set('display_errors', 0);
error_reporting(0);

// Allow access from anywhere (no referrer check)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// Set proper permissions for uploaded files
umask(0);

$db_file = __DIR__ . '/users.db';
try {
    $db = new PDO('sqlite:' . $db_file);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    die('Database connection error');
}

if (!isset($_GET['file'])) {
    http_response_code(400);
    die('Invalid request - missing file parameter');
}

// Get user ID from parameter (u or user)
$user_id = intval($_GET['u'] ?? $_GET['user'] ?? 0);

if ($user_id === 0) {
    http_response_code(400);
    die('Invalid request - missing user parameter');
}

$filename = basename($_GET['file']);
$filepath = __DIR__ . '/uploads/' . $user_id . '/' . $filename;

// Fix file permissions if they exist
if (file_exists($filepath)) {
    @chmod($filepath, 0644);
}

if (!file_exists($filepath)) {
    http_response_code(404);
    die('File not found: ' . htmlspecialchars($filename));
}

// Check if file is readable
if (!is_readable($filepath)) {
    @chmod($filepath, 0644);
    if (!is_readable($filepath)) {
        http_response_code(403);
        die('File not readable. Please contact admin.');
    }
}

// Check if file is password protected
$stmt = $db->prepare("SELECT password FROM file_passwords WHERE user_id = ? AND filename = ?");
$stmt->execute([$user_id, $filename]);
$password_data = $stmt->fetch(PDO::FETCH_ASSOC);

$is_protected = $password_data !== false;

// Handle password verification
if ($is_protected) {
    $session_key = 'file_access_' . $user_id . '_' . $filename;
    
    if (isset($_POST['verify_password'])) {
        $entered_password = $_POST['password'];
        if (password_verify($entered_password, $password_data['password'])) {
            $_SESSION[$session_key] = true;
        } else {
            $error = 'Incorrect password!';
        }
    }
    
    // Check if user has access
    if (!isset($_SESSION[$session_key]) || $_SESSION[$session_key] !== true) {
        // Show password form
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Protected</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
        <style>
        :root{--bg:#dde1e7;--text:#595959;--light:#fff;--dark:#babecc;--blue:#007bff}
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}
        body{background:var(--bg);min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
        input{-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}
        .card{width:100%;max-width:450px;background:var(--bg);border-radius:25px;box-shadow:8px 8px 16px var(--dark),-8px -8px 16px var(--light);padding:40px;text-align:center}
        .lock-icon{font-size:5rem;color:var(--blue);margin-bottom:20px}
        h1{font-weight:700;color:var(--text);margin-bottom:10px;font-size:1.8rem}
        .sub{font-size:.9rem;color:#888;margin-bottom:30px}
        .field{position:relative;margin-bottom:20px}
        .field i{position:absolute;left:20px;top:50%;transform:translateY(-50%);color:var(--text);z-index:1}
        .input{width:100%;height:50px;background:var(--bg);border:none;border-radius:25px;box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light);padding:0 20px 0 50px;color:var(--text);font-size:1rem;outline:none}
        .btn{width:100%;height:50px;border-radius:25px;background:var(--bg);box-shadow:5px 5px 10px var(--dark),-5px -5px 10px var(--light);border:none;color:var(--text);font-weight:600;font-size:1rem;cursor:pointer;margin-top:20px;display:flex;align-items:center;justify-content:center;transition:.3s}
        .btn:hover{color:var(--blue)}
        .btn:active{box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light)}
        .error{padding:12px;border-radius:15px;margin-bottom:20px;font-size:.85rem;font-weight:600;color:#f44;background:rgba(255,68,68,.1);box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light)}
        .filename{background:var(--bg);border-radius:15px;padding:15px;margin-bottom:25px;box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light);word-break:break-all;color:var(--text);font-size:.85rem}
        </style>
        </head>
        <body>
        <div class="card">
        <div class="lock-icon"><i class="fas fa-lock"></i></div>
        <h1>Password Protected</h1>
        <p class="sub">This file requires a password to view</p>
        <?php if(isset($error)): ?><div class="error"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error);?></div><?php endif;?>
        <div class="filename"><i class="fas fa-file"></i> <?php echo htmlspecialchars($filename);?></div>
        <form method="POST">
        <div class="field">
        <i class="fas fa-key"></i>
        <input type="password" name="password" class="input" placeholder="Enter password" required autofocus>
        </div>
        <button type="submit" name="verify_password" class="btn">
        <i class="fas fa-unlock" style="margin-right:10px;"></i>Unlock & View
        </button>
        </form>
        </div>
        <script>
        document.addEventListener('contextmenu', function(e) { e.preventDefault(); });
        document.addEventListener('selectstart', function(e) { if(e.target.tagName !== 'INPUT') e.preventDefault(); });
        </script>
        </body>
        </html>
        <?php
        exit();
    }
}

// If we're here, user has access (either no password or correct password entered)
$ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));

// Check if it's a media file that should be displayed in a player
$video_exts = ['mp4', 'webm', 'avi', 'mov'];
$audio_exts = ['mp3', 'wav', 'ogg'];
$is_video = in_array($ext, $video_exts);
$is_audio = in_array($ext, $audio_exts);

// If it's video or audio, show in embedded player
if ($is_video || $is_audio) {
    $mime_types = [
        'mp4' => 'video/mp4',
        'webm' => 'video/webm',
        'avi' => 'video/x-msvideo',
        'mov' => 'video/quicktime',
        'mp3' => 'audio/mpeg',
        'wav' => 'audio/wav',
        'ogg' => 'audio/ogg'
    ];
    $mime = $mime_types[$ext];
    
    // Check if this is a range request (for streaming)
    $filesize = filesize($filepath);
    $length = $filesize;
    $start = 0;
    $end = $filesize - 1;
    
    header('Content-Type: ' . $mime);
    header('Accept-Ranges: bytes');
    
    if (isset($_SERVER['HTTP_RANGE'])) {
        $c_start = $start;
        $c_end = $end;
        
        list(, $range) = explode('=', $_SERVER['HTTP_RANGE'], 2);
        if (strpos($range, ',') !== false) {
            header('HTTP/1.1 416 Requested Range Not Satisfiable');
            header('Content-Range: bytes */' . $filesize);
            exit;
        }
        
        if ($range == '-') {
            $c_start = $filesize - substr($range, 1);
        } else {
            $range = explode('-', $range);
            $c_start = $range[0];
            $c_end = (isset($range[1]) && is_numeric($range[1])) ? $range[1] : $filesize;
        }
        
        $c_end = ($c_end > $end) ? $end : $c_end;
        if ($c_start > $c_end || $c_start > $filesize - 1 || $c_end >= $filesize) {
            header('HTTP/1.1 416 Requested Range Not Satisfiable');
            header('Content-Range: bytes */' . $filesize);
            exit;
        }
        
        $start = $c_start;
        $end = $c_end;
        $length = $end - $start + 1;
        
        header('HTTP/1.1 206 Partial Content');
        header('Content-Range: bytes ' . $start . '-' . $end . '/' . $filesize);
    }
    
    header('Content-Length: ' . $length);
    
    $fp = fopen($filepath, 'rb');
    fseek($fp, $start);
    
    $buffer = 1024 * 8;
    while (!feof($fp) && ($p = ftell($fp)) <= $end) {
        if ($p + $buffer > $end) {
            $buffer = $end - $p + 1;
        }
        echo fread($fp, $buffer);
        flush();
    }
    
    fclose($fp);
    exit;
}

// For other files, serve normally
$mime_types = [
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif',
    'webp' => 'image/webp',
    'svg' => 'image/svg+xml',
    'html' => 'text/html',
    'htm' => 'text/html',
    'css' => 'text/css',
    'js' => 'application/javascript',
    'php' => 'text/plain',
    'txt' => 'text/plain'
];

$mime = isset($mime_types[$ext]) ? $mime_types[$ext] : 'application/octet-stream';

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($filepath));

// For PHP files, show as plain text for security
if ($ext === 'php') {
    echo htmlspecialchars(file_get_contents($filepath));
} else {
    readfile($filepath);
}
?>
