<?php
session_start();
ini_set('display_errors', 0);
error_reporting(0);

// Allow access from anywhere (no referrer check)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

$db_file = __DIR__ . '/users.db';
try {
    $db = new PDO('sqlite:' . $db_file);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    die('Database connection error');
}

if (!isset($_GET['file'])) {
    http_response_code(400);
    die('Invalid request - missing file parameter');
}

// Get user ID from parameter (u or user)
$user_id = intval($_GET['u'] ?? $_GET['user'] ?? 0);

if ($user_id === 0) {
    http_response_code(400);
    die('Invalid request - missing user parameter');
}

$filename = basename($_GET['file']);
$filepath = __DIR__ . '/uploads/' . $user_id . '/' . $filename;

if (!file_exists($filepath)) {
    http_response_code(404);
    die('File not found: ' . htmlspecialchars($filename));
}

// Check if file is password protected
$stmt = $db->prepare("SELECT password FROM file_passwords WHERE user_id = ? AND filename = ?");
$stmt->execute([$user_id, $filename]);
$password_data = $stmt->fetch(PDO::FETCH_ASSOC);

$is_protected = $password_data !== false;

// Handle password verification
if ($is_protected) {
    $session_key = 'file_access_' . $user_id . '_' . $filename;
    
    if (isset($_POST['verify_password'])) {
        $entered_password = $_POST['password'];
        if (password_verify($entered_password, $password_data['password'])) {
            $_SESSION[$session_key] = true;
        } else {
            $error = 'Incorrect password!';
        }
    }
    
    // Check if user has access
    if (!isset($_SESSION[$session_key]) || $_SESSION[$session_key] !== true) {
        // Show password form
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Protected</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
        <style>
        :root{--bg:#dde1e7;--text:#595959;--light:#fff;--dark:#babecc;--blue:#007bff}
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}
        body{background:var(--bg);min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}
        input{-webkit-user-select:text;-moz-user-select:text;-ms-user-select:text;user-select:text}
        .card{width:100%;max-width:450px;background:var(--bg);border-radius:25px;box-shadow:8px 8px 16px var(--dark),-8px -8px 16px var(--light);padding:40px;text-align:center}
        .lock-icon{font-size:5rem;color:var(--blue);margin-bottom:20px}
        h1{font-weight:700;color:var(--text);margin-bottom:10px;font-size:1.8rem}
        .sub{font-size:.9rem;color:#888;margin-bottom:30px}
        .field{position:relative;margin-bottom:20px}
        .field i{position:absolute;left:20px;top:50%;transform:translateY(-50%);color:var(--text);z-index:1}
        .input{width:100%;height:50px;background:var(--bg);border:none;border-radius:25px;box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light);padding:0 20px 0 50px;color:var(--text);font-size:1rem;outline:none}
        .btn{width:100%;height:50px;border-radius:25px;background:var(--bg);box-shadow:5px 5px 10px var(--dark),-5px -5px 10px var(--light);border:none;color:var(--text);font-weight:600;font-size:1rem;cursor:pointer;margin-top:20px;display:flex;align-items:center;justify-content:center;transition:.3s}
        .btn:hover{color:var(--blue)}
        .btn:active{box-shadow:inset 5px 5px 10px var(--dark),inset -5px -5px 10px var(--light)}
        .error{padding:12px;border-radius:15px;margin-bottom:20px;font-size:.85rem;font-weight:600;color:#f44;background:rgba(255,68,68,.1);box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light)}
        .filename{background:var(--bg);border-radius:15px;padding:15px;margin-bottom:25px;box-shadow:inset 3px 3px 6px var(--dark),inset -3px -3px 6px var(--light);word-break:break-all;color:var(--text);font-size:.85rem}
        </style>
        </head>
        <body>
        <div class="card">
        <div class="lock-icon"><i class="fas fa-lock"></i></div>
        <h1>Password Protected</h1>
        <p class="sub">This file requires a password to view</p>
        <?php if(isset($error)): ?><div class="error"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error);?></div><?php endif;?>
        <div class="filename"><i class="fas fa-file"></i> <?php echo htmlspecialchars($filename);?></div>
        <form method="POST">
        <div class="field">
        <i class="fas fa-key"></i>
        <input type="password" name="password" class="input" placeholder="Enter password" required autofocus>
        </div>
        <button type="submit" name="verify_password" class="btn">
        <i class="fas fa-unlock" style="margin-right:10px;"></i>Unlock & View
        </button>
        </form>
        </div>
        <script>
        document.addEventListener('contextmenu', function(e) { e.preventDefault(); });
        document.addEventListener('selectstart', function(e) { if(e.target.tagName !== 'INPUT') e.preventDefault(); });
        </script>
        </body>
        </html>
        <?php
        exit();
    }
}

// Get file extension and type
$ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));
$video_exts = ['mp4', 'webm', 'avi', 'mov'];
$audio_exts = ['mp3', 'wav', 'ogg'];
$is_video = in_array($ext, $video_exts);
$is_audio = in_array($ext, $audio_exts);

// Build the stream URL
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443 ? "https" : "http";
$base_path = dirname($_SERVER['PHP_SELF']);
$stream_url = $protocol."://".$_SERVER['HTTP_HOST'].$base_path."/view.php?file=".rawurlencode($filename)."&u=".$user_id;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($filename);?></title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#0f0f0f;--text:#fff;--light:#1f1f1f;--dark:#000;--blue:#3ea6ff;--purple:#9146ff}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}
body{background:var(--bg);min-height:100vh;display:flex;flex-direction:column;color:var(--text)}
.header{background:var(--light);padding:15px 30px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 2px 10px rgba(0,0,0,.5)}
.filename{font-size:1.1rem;font-weight:600;color:var(--text);word-break:break-word;flex:1}
.back-btn{background:var(--blue);color:#fff;padding:10px 20px;border-radius:20px;text-decoration:none;font-weight:600;font-size:.9rem;display:flex;align-items:center;gap:8px;transition:.3s;border:none;cursor:pointer}
.back-btn:hover{opacity:.8}
.player-container{flex:1;display:flex;align-items:center;justify-content:center;padding:20px}
.video-wrapper{width:100%;max-width:1200px}
.audio-wrapper{width:100%;max-width:600px}
.audio-card{background:linear-gradient(135deg,var(--light) 0%,#2a2a2a 100%);padding:50px 40px;border-radius:25px;box-shadow:0 20px 60px rgba(0,0,0,.8)}
.audio-icon{text-align:center;margin-bottom:30px}
.audio-icon i{font-size:6rem;color:var(--purple);animation:pulse 2s ease-in-out infinite}
@keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.05)}}
.audio-title{text-align:center;margin-bottom:30px;font-size:1.3rem;font-weight:600;color:var(--text);word-break:break-word}
video{width:100%;border-radius:15px;box-shadow:0 15px 50px rgba(0,0,0,.9);outline:none}
audio{width:100%;height:50px;outline:none;border-radius:10px}
audio::-webkit-media-controls-panel{background:linear-gradient(to right,var(--blue),var(--purple))}
.controls-info{text-align:center;margin-top:20px;color:#aaa;font-size:.85rem}
@media(max-width:768px){.header{padding:12px 15px;flex-direction:column;gap:10px;text-align:center}.filename{font-size:.9rem}.audio-card{padding:35px 25px}.audio-icon i{font-size:4.5rem}.audio-title{font-size:1.1rem}}
</style>
</head>
<body>
<div class="header">
<div class="filename"><i class="fas fa-<?php echo $is_video ? 'video' : 'music';?>"></i> <?php echo htmlspecialchars($filename);?></div>
<button onclick="window.history.back()" class="back-btn"><i class="fas fa-arrow-left"></i>Back</button>
</div>
<div class="player-container">
<?php if($is_video): ?>
<div class="video-wrapper">
<video id="videoPlayer" controls>
<source src="<?php echo htmlspecialchars($stream_url);?>" type="video/<?php echo $ext === 'avi' ? 'x-msvideo' : ($ext === 'mov' ? 'quicktime' : $ext);?>">
Your browser does not support video playback.
</video>
</div>
<?php elseif($is_audio): ?>
<div class="audio-wrapper">
<div class="audio-card">
<div class="audio-icon">
<i class="fas fa-headphones"></i>
</div>
<div class="audio-title"><?php echo htmlspecialchars(pathinfo($filename, PATHINFO_FILENAME));?></div>
<audio id="audioPlayer" controls>
<source src="<?php echo htmlspecialchars($stream_url);?>" type="audio/<?php echo $ext === 'mp3' ? 'mpeg' : $ext;?>">
Your browser does not support audio playback.
</audio>
</div>
</div>
<?php else: ?>
<p style="color:#999;">File type not supported for playback</p>
<?php endif;?>
</div>
<?php if($is_video || $is_audio): ?>
<div class="controls-info">
<i class="fas fa-info-circle"></i> Use player controls to play, pause, seek, and adjust volume
</div>
<?php endif;?>
<script>
// Disable right-click
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
    return false;
});

// Disable text selection
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
    return false;
});

// Try to play automatically when page loads
document.addEventListener('DOMContentLoaded', function() {
    <?php if($is_video): ?>
    const video = document.getElementById('videoPlayer');
    if(video) {
        video.play().catch(e => console.log('Autoplay prevented:', e));
    }
    <?php elseif($is_audio): ?>
    const audio = document.getElementById('audioPlayer');
    if(audio) {
        audio.play().catch(e => console.log('Autoplay prevented:', e));
    }
    <?php endif;?>
});
</script>
</body>
</html>
